# AI-Assisted Research Report

Title: *AI-Assisted Research Report: A counterexample to Scottish Book Problem 155*

- Author: Yoshito Ishiki
- Version: 1.0
- Date: 30 August 2026
- License: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)

This archive contains the LaTeX source used to build the published Version 1.0 PDF.
OpenAI Codex assisted with mathematical exploration, proof development, literature searches, language editing, and LaTeX preparation.
The author verified the arguments and takes full responsibility for the mathematical content and the final version of the manuscript.

## Build

The source uses LuaLaTeX, Biber, and `latexmk`.
With [Kicho](https://github.com/yoshito-ishiki-math/kicho) installed, run:

```bash
kicho check
kicho build
```

Alternatively, run `latexmk` from this directory.
